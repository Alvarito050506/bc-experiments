var maze = [
	[1, 4, 0, 0, 0, 0, 0, 0],
	[0, 5, 4, 0, 0, 0, 0, 0],
	[0, 0, 2, 0, 0, 0, 0, 0],
	[0, 0, 2, 0, 0, 0, 0, 0],
	[0, 0, 5, 1, 4, 0, 0, 0],
	[0, 0, 0, 0, 2, 0, 0, 0],
	[0, 0, 3, 1, 1, 4, 0, 0],
	[0, 0, 2, 0, 0, 5, 1, 1]
];

var spritesheet = {
	"pipe_vertical": {
		"sx": 0,
		"sy": 0,
		"sWidth": 95,
		"sHeigth": 119
	},
	"pipe_horizontal": {
		"sx": 95,
		"sy": 0,
		"sWidth": 95,
		"sHeigth": 119
	},
	"hamster_front": {
		"sx": 190,
		"sy": 0,
		"sWidth": 95,
		"sHeigth": 119
	},
	"hamster_back": {
		"sx": 285,
		"sy": 0,
		"sWidth": 95,
		"sHeigth": 119
	},
	"hamster_left": {
		"sx": 0,
		"sy": 119,
		"sWidth": 95,
		"sHeigth": 119
	},
	"hamster_right": {
		"sx": 95,
		"sy": 119,
		"sWidth": 95,
		"sHeigth": 119
	},
	"pipe_corner_1": {
		"sx": 190,
		"sy": 119,
		"sWidth": 95,
		"sHeigth": 119
	},
	"pipe_corner_2": {
		"sx": 285,
		"sy": 119,
		"sWidth": 95,
		"sHeigth": 119
	},
	"pipe_corner_3": {
		"sx": 0,
		"sy": 238,
		"sWidth": 95,
		"sHeigth": 119
	},
	"pipe_corner_4": {
		"sx": 95,
		"sy": 238,
		"sWidth": 95,
		"sHeigth": 119
	}
};

var hamster_char = new uChar("sprites.png", spritesheet);
var hamster = new uElement(0, 59.5 / 2.5, hamster_char, "hamster");
var hx = 0;
var hy = 0;
hamster.w = 47.5;
hamster.h = 59.5;
hamster.char.changeSprite("hamster_front");

var map = ["pipe_horizontal", "pipe_vertical", "pipe_corner_1", "pipe_corner_2", "pipe_corner_3", "pipe_corner_4"];

function main()
{
	uCanv.ctx = document.getElementById("canvas").getContext("2d");
	loop();
}

function loop()
{
	uCanv.ctx.clearRect(0, 0, 595, 595);
	uCanv.ctx.fillRect(0, 0, 595, 595);
	var x = 0;
	var y = 0;
	maze.forEach(function (row) {
		row.forEach(function (column) {
			if (column != 0)
			{
				var pipe_char = new uChar("sprites.png", spritesheet);
				var pipe = new uElement(x * 47.5, y * (59.5 / 2.5) + 59.5, pipe_char);
				pipe.char.changeSprite(map[column - 1]);
				pipe.w = 47.5;
				pipe.h = 59.5;
				pipe.draw();
			}
			x += 1;
		});
		x = 0;
		y += 1;
	});
	hamster.draw();
	requestAnimationFrame(loop);
}

document.addEventListener("keypress", function (event) {
	var k = event.key.toLowerCase();
	/*if (k == "w" || k == "a" || k == "s" || k == "d")
	{
		console.log(k);
	}*/
	if (k == "w")
	{
		hamster.char.changeSprite("hamster_back");
		if (maze[hy - 1] && maze[hy - 1][hx] != 0)
		{
			hamster.move(hamster.x, hamster.y - 59.5 / 2.5);
			hy -= 1;
		}
	} else if (k == "a")
	{
		hamster.char.changeSprite("hamster_left");
		if (maze[hy][hx - 1] && maze[hy][hx - 1] != 0)
		{
			hamster.move(hamster.x - 47.5, hamster.y);
			hx -= 1;
		}
	} else if (k == "s")
	{
		hamster.char.changeSprite("hamster_front");
		if (maze[hy + 1] && maze[hy + 1][hx] != 0)
		{
			hamster.move(hamster.x, hamster.y + 59.5 / 2.5);
			hy += 1;
		}
	} else if (k == "d")
	{
		hamster.char.changeSprite("hamster_right");
		if (maze[hy][hx + 1] && maze[hy][hx + 1] != 0)
		{
			hamster.move(hamster.x + 47.5, hamster.y);
			hx += 1;
		}
	}
});

main();
